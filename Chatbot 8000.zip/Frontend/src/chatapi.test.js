import { vi } from 'vitest';
import axios from 'axios';

vi.mock('axios');

describe('/chat endpoint', () => {
  let app;

  beforeAll(async () => {
    const mod = await import(`${process.cwd()}/api_server.js`);
    app = mod.default || mod.app;
  });

  it('returns 200 and server response', async () => {
    axios.post.mockResolvedValueOnce({ data: { response: 'pong' } });
    const response = await axios.post('http://localhost:5000/chat', { message: 'hello' });

    expect(response.status).toBe(200);
    expect(response.data).toBeDefined();
  });

  it('returns 500 on LLM failure', async () => {
    axios.post.mockRejectedValueOnce(new Error('LLM failed'));
    try {
      await axios.post('http://localhost:5000/chat', { message: 'error' });
    } catch (error) {
      expect(error.response.status).toBe(500);
    }
  });
});
