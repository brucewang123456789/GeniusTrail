import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { vi } from 'vitest';
import axios from 'axios';
import Chatbox from '@components/Chatbox';  // 确保使用别名

vi.mock('axios');  // Mock axios

describe('<Chatbox />', () => {
  it('disables the “Send” button while waiting', async () => {
    // Mock API call
    axios.post.mockResolvedValueOnce({ data: { response: 'pong' } });

    render(<Chatbox />);

    // Simulate user typing and clicking the button
    fireEvent.change(screen.getByPlaceholderText('Type a message...'), { target: { value: 'ping' } });
    const button = screen.getByRole('button', { name: 'Send' });
    fireEvent.click(button);

    // Assert the button is disabled
    expect(button).toBeDisabled();

    // Wait for the button to be enabled after response
    await waitFor(() => expect(button).not.toBeDisabled());
    expect(screen.getByText('pong')).toBeInTheDocument();
  });

  it('shows an error if the request fails', async () => {
    axios.post.mockRejectedValueOnce(new Error('Network down'));
    render(<Chatbox />);

    fireEvent.change(screen.getByPlaceholderText('Type a message...'), { target: { value: 'hello' } });
    fireEvent.click(screen.getByRole('button', { name: 'Send' }));

    await screen.findByText(/Error: failed to fetch/i);
  });
});
