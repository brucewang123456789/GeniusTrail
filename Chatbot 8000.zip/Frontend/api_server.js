import express from 'express';
import axios from 'axios';

const app = express();
app.use(express.json());

const API_URL = 'https://api.yourmodel.com/chat';  // Example URL for your AI model

app.post('/chat', async (req, res) => {
  try {
    const response = await axios.post(API_URL, {
      message: req.body.message,
    });
    res.status(200).send(response.data);
  } catch (error) {
    res.status(500).send({ error: 'Failed to fetch data' });
  }
});

app.listen(5000, () => {
  console.log('Server running on port 5000');
});
