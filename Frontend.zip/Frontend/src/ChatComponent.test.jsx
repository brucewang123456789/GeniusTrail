import React, { useState } from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { rest } from 'msw';  // 确保正确导入 rest
import { setupServer } from 'msw/node';  // 确保正确导入 setupServer

// Mock server setup
const server = setupServer(
  rest.post('/chat', (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
        success: true,
        message: 'Mocked chat response',
        data: { text: 'Hello, world!' }
      })
    );
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

// 组件实现
const ChatComponent = ({ onMessageSend }) => {
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState(null);
  const [error, setError] = useState(null);

  const handleMessageChange = (e) => setMessage(e.target.value);

  const handleSend = async () => {
    try {
      const res = await fetch('/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
      const json = await res.json();
      if (res.ok) setResponse(json.data.text);
      else throw new Error(json.error);
    } catch (e) {
      setError(`An error occurred: ${e.message}`);
    }
    setMessage('');
  };

  return (
    <div>
      <h1>Chat Component</h1>
      <input
        type="text"
        value={message}
        onChange={handleMessageChange}
        placeholder="Type a message"
      />
      <button onClick={handleSend}>Send</button>
      {response && <p>{response}</p>}
      {error && <p>{error}</p>}
    </div>
  );
};

// 测试
test('renders and handles successful response', async () => {
  render(<ChatComponent />);
  fireEvent.change(screen.getByPlaceholderText(/Type a message/i), {
    target: { value: 'Hello!' }
  });
  fireEvent.click(screen.getByText(/Send/i));

  await waitFor(() =>
    expect(screen.getByText('Hello, world!')).toBeInTheDocument()
  );
});

test('handles server error response', async () => {
  server.use(
    rest.post('/chat', (req, res, ctx) => {
      return res(
        ctx.status(500),
        ctx.json({
          success: false,
          error: 'Internal Server Error',
        })
      );
    })
  );

  render(<ChatComponent />);
  fireEvent.change(screen.getByPlaceholderText(/Type a message/i), {
    target: { value: 'Hello!' }
  });
  fireEvent.click(screen.getByText(/Send/i));

  await waitFor(() =>
    expect(
      screen.getByText('An error occurred: Internal Server Error')
    ).toBeInTheDocument()
  );
});
