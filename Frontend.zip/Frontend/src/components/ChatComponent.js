// src/components/Chatbox/ChatComponent.js

import React, { useState } from 'react';

const ChatComponent = ({ onMessageSend }) => {
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');
  const [error, setError] = useState(null);

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const handleSend = async () => {
    if (onMessageSend) {
      try {
        const res = await onMessageSend(message); // Simulating message send
        if (res.success) {
          setResponse(res.data.text); // Set response message on success
        } else {
          setError(res.error); // Set error on failure
        }
      } catch (err) {
        setError('An unexpected error occurred');
      }
    }
    setMessage('');
  };

  return (
    <div>
      <h1>Chat Component</h1>
      <input
        type="text"
        value={message}
        onChange={handleMessageChange}
        placeholder="Type a message"
      />
      <button onClick={handleSend}>Send</button>
      {response && <div>{response}</div>} {/* Display success response */}
      {error && <div>An error occurred: {error}</div>} {/* Display error message */}
    </div>
  );
};

export default ChatComponent;
