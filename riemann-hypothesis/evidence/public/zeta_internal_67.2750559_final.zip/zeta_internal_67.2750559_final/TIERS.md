# TIERS — proof value versus verification cost

Author: Libo Wang. Frozen 2026-09-17.

The programme now keeps two numerical tiers because the largest decimal and the cheapest
verifiable witness optimize different objectives.

| tier | C | local-verifier cost | release status |
|---|---:|---:|---|
| **short-certificate (primary release)** | **67.275055959117140%** | **793,374 nodes** | 4/4 inequalities independently replayed in this finalization |
| maximum-value research tier | 67.350003708785593% | historical run reported 428,006,362 nodes | exact assembly present; the supplied v10 handoff does **not** contain the complete raw 48-shard log set, so this finalization does not claim an independent re-audit of all local shards |

## Why the short tier exists

The local verifier cost is controlled primarily by certification margin, not merely by the
dimension. The high-value tier pushes epsilon close to the actual minima and leaves margins of
order 3e-5, which drives branch-and-bound into hundreds of millions of nodes. The short tier
sets the target by the threshold that actually matters for the external verification goal, then
spends the available numerical slack on easier epsilon values.

Frozen short witness: `q=8`, `m=617`, `eta=119/125`, with

- `eps(1/2)=279/50000`,
- `eps(19/20)=33669/5000000`,
- `eps(1)=34219/5000000`,
- `eps(21/20)=17333/2500000`.

The exact assembly minimum is `R=1256139843/312500000`, attained at the `E=0` kink, and

`C=9484806128780811321/14098548107555200000`.

## Cost curve that motivated the choice

For `s=1`, the observed branch-and-bound node count collapses as epsilon is relaxed:

| epsilon | observed nodes |
|---:|---:|
| 0.0080132 | 213,519,829 |
| 0.0072 | 1,399,238 |
| 0.0070 | 552,762 |
| 0.0065 | 49,125 |
| 0.0060 | 3,256 |
| 0.0053 | 111 |

The frozen four-slope short tier uses 793,374 nodes total. A still looser common relaxation
near 1.6e-3 falls below the official 67.2500703679% challenge record, so the short tier keeps a
comfortable score margin without defending unnecessary decimal places.

## External comparison, carefully separated

As checked on 2026-09-17, `riemannzeta.fun` still displays 67.2500703679% as its current
kernel-verified record. Therefore the short tier is numerically above the **official challenge
record**, but it is not on that leaderboard because no accepted Lean submission exists.

A separate public research repository (`ainta/zeta-simple-zeros`) reports a 67.3008528% finite
verification. It is higher than this short tier and, at the same date, is not the value displayed
as the official kernel-verified record. Consequently this release does **not** call 67.2750559%
the highest public mathematical claim.

Sources:
- https://www.riemannzeta.fun/
- https://www.riemannzeta.fun/challenge
- https://github.com/ainta/zeta-simple-zeros

## L11 — transferable rule

**节点数由余量驱动；先确定真正要超越的阈值，再据此反推可放松的 ε。**

In English: node count is margin-driven; first identify the threshold that actually has to be
beaten, then solve backward for the loosest epsilon values that preserve a strict improvement.
