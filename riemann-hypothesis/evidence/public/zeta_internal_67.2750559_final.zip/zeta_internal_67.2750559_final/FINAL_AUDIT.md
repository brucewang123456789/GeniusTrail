# FINAL_AUDIT — release closure

Author: Libo Wang. Audit date: 2026-09-17.

## What was independently re-run in this finalization

1. `verify_exact.py` from the supplied v10 handoff: exact-rational assembly of the 67.3500037% tier passed.
2. The four frozen short-tier local inequalities were recompiled from `verifier/bb9.cpp` and all returned `PROVED` with zero stack and zero HARD boxes. Their node counts sum to 793,374.
3. `verify_short.py` was built from the frozen rational data and independently reproduces the exact short-tier fraction 9484806128780811321/14098548107555200000.
4. SHA-256 manifests were regenerated after all edits and checked.

## What was not independently re-run here

- The high-value tier's full historical 48-shard computation: the supplied v10 archive contains only the `s=1/2` raw shard logs even though its summary text describes all 48. This release therefore preserves that tier as research provenance but does not present the missing logs as if they were present.
- `arb_window.py`: the current sandbox has no `python-flint`, and outbound package installation is unavailable. The script and requirement are preserved; the final package does not silently substitute ordinary floating point for Arb.
- Lean submission: no complete `proof/Solution.lean` satisfying the challenge contract exists, so no leaderboard submission was attempted.

## Claim boundary

The strongest self-contained claim of this final package is the **short finite certificate tier**:
its four local inequalities and exact assembly are reproducible from included source. It remains
outside the Lean/nanoda acceptance pipeline and therefore must not be described as an accepted
leaderboard record or as peer-reviewed mathematical consensus.
