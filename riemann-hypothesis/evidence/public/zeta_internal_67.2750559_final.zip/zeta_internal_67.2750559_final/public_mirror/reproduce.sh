#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
echo "== exact short-tier rational chain + committed-log audit =="
python3 verify_short.py
echo
echo "== inherited maximum-tier exact assembly (provenance check) =="
python3 verify_exact.py
echo
echo "Core offline checks passed."
echo "To replay the four short local certificates: sh run_short.sh"
echo "To rerun the Arb window check (requires python-flint): python3 arb_window.py"
