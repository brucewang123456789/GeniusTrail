# SHORT_RESULTS — frozen short-certificate tier

Author: Libo Wang. Finalization replay date: 2026-09-17.

All four local inequalities were independently replayed from `verifier/bb9.cpp` during this
finalization. A result is accepted only when the verifier reports `result=PROVED`,
`stack_left=0`, and `HARD=0`. The node cap was 2,000,000 per run, table step 1/4096,
and `wmin=0.001`.

| slope | epsilon | nodes | terminal state |
|---:|---:|---:|---|
| 1/2 | 279/50000 = 0.00558 | 12,270 | PROVED; stack=0; HARD=0 |
| 19/20 | 33669/5000000 = 0.0067338 | 212,210 | PROVED; stack=0; HARD=0 |
| 1 | 34219/5000000 = 0.0068438 | 265,637 | PROVED; stack=0; HARD=0 |
| 21/20 | 17333/2500000 = 0.0069332 | 303,257 | PROVED; stack=0; HARD=0 |
| **total** |  | **793,374** | **4/4 PROVED** |

The first run in a clean directory constructs a fine lookup table; later runs reuse the cache.
The cache is a derived speed artifact and is deliberately not part of the release.

Exact assembly is checked by `python3 verify_short.py` and gives

`C = 9484806128780811321 / 14098548107555200000 = 67.275055959117140%`.

This is a finite verifier result outside Lean. It is not, by itself, an accepted entry in the
`riemannzeta.fun` kernel-verified leaderboard.
