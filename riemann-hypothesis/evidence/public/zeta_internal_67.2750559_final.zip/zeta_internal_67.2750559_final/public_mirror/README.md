# VeriLoop zeta programme — reproducible short-certificate release

**Author: Libo Wang**  
Frozen release: **2026-09-17**

This release freezes the proof-cost-optimal tier of the programme:

`C = 9484806128780811321 / 14098548107555200000 = 67.275055959117140%`.

The four eight-gap local inequalities required by this tier were independently replayed in the
finalization from the included `verifier/bb9.cpp`: **4/4 PROVED, 793,374 nodes total, zero
unresolved boxes**. The exact rational assembly is checked by `verify_short.py`.

This is **not** an accepted `riemannzeta.fun` entry: the challenge requires a complete Lean proof
replayed by two kernels, and that formalization is not present. See `STATUS.md` and
`FINAL_AUDIT.md` before quoting the result.

## Two frozen tiers

| tier | value | role |
|---|---:|---|
| **short-certificate** | **67.275055959117140%** | primary public/reproducible tier; fresh 4/4 replay in this release |
| maximum-value research tier | 67.350003708785593% | higher exact assembly retained for research; complete historical raw 48-shard log set is not contained in the supplied v10 handoff |

The principle behind the split is recorded in `TIERS.md`: **node count is driven by margin;
choose the threshold that truly matters first, then solve backward for the loosest epsilon that
still beats it.**

## Reproduce the primary tier

```sh
python3 verify_short.py
sh run_short.sh
```

`run_short.sh` builds `bb9.cpp`, constructs its derived fine-table cache on the first clean run,
and reruns the four inequalities fail-closed. Expected node counts are 12,270, 212,210,
265,637, and 303,257.

For the inherited analytic/window checks:

```sh
pip install -r requirements.txt
python3 arb_window.py
```

The release deliberately does not replace Arb with non-rigorous ordinary floating point when
`python-flint` is unavailable.

## Current external context

On 2026-09-17 the official `riemannzeta.fun` challenge page displays **67.2500703679%** as the
kernel-verified record. The short tier is numerically above that threshold, but no valid Lean
submission has been completed. Separately, the public `ainta/zeta-simple-zeros` research
repository reports **67.3008528%**, above this short tier; it is not the value displayed as the
official challenge record on the same date. See `TIERS.md`/`SUBMISSION.md` for the distinction.

## Key files

| file | purpose |
|---|---|
| `TIERS.md` | short vs maximum tier, cost curve, L11 |
| `config/shortlock.json` | immutable short-tier constants and expected node counts |
| `verify_short.py` | exact-rational assembly and committed-log audit |
| `run_short.sh` | one-command replay of all four short certificates |
| `certificates/SHORT_RESULTS.md` | fresh finalization run ledger |
| `FINAL_AUDIT.md` | what was and was not independently re-run |
| `THEORY.md`, `AUDIT.md` | mathematical reduction and finite algebra |
| `SUBMISSION.md`, `lean/` | Lean contract and remaining formalization boundary |
| `verifier/bb9.cpp` | fail-closed interval branch-and-bound verifier |
| `MANIFEST.sha256` | release integrity |

MIT. Released for independent scrutiny.
