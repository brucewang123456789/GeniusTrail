# Certificates

Author: Libo Wang.

## Primary short tier

See `certificates/SHORT_RESULTS.md` and the four raw logs under `certificates/short/`.
`run_short.sh` independently regenerates them from `verifier/bb9.cpp` and fails unless every
terminal line has `result=PROVED`, `stack_left=0`, and `HARD=0`, with the frozen node count.

Frozen total: **793,374 nodes**.

## Historical maximum-value tier

The supplied v10 handoff includes the high-value configuration and summary text, but its archive
does not contain the complete raw 48-shard log set described by that summary; only the `s=1/2`
shard logs are actually present. Those legacy materials are retained for provenance, but the
primary release claim is deliberately based on the short tier that was independently replayed in
full during finalization.
