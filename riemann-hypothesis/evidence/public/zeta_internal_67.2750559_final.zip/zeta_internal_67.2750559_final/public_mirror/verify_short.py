"""Exact-rational verification of the frozen short-certificate q=8 tier.
No floating point participates in an acceptance test.
"""
import json, math, re, sys
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent
rat=json.load(open(ROOT/'config/cfgA_rat.json'))
ex=json.load(open(ROOT/'config/shortlock.json'))
ok=True

def ck(name,cond):
    global ok
    cond=bool(cond); ok &= cond
    print(("  PASS  " if cond else "  FAIL  ")+name)

Hf=F(*ex['H']); m=int(ex['m']); eta=F(*ex['eta']); Rc=F(*ex['R']); Cc=F(*ex['C'])
eps={F(k):F(*v) for k,v in ex['eps'].items()}
q=int(ex['q']); d=2*q; T=F(q+1,q); B=F(93,23000)
a={tuple(int(t) for t in k.split(',')):F(*v) for k,v in rat['a'].items()}
for sp in range(1,q+1):
    ck(f"span {sp} capacity == 2", sum(a[(i,i+sp)] for i in range(q+1-sp))==2)
ck("all a_ij >= 0", all(v>=0 for v in a.values()))
b=[F(*v) for v in rat['b']]
ck("B == 93/23000", sum(b)==B)
ck("all b_r >= 0", all(v>=0 for v in b))

def sq_floor(x,K=10**30):
    r=F(math.isqrt(x.numerator*K*K//x.denominator),K)
    while r*r>x: r-=F(1,K)
    return r

def h(E):
    return E if E<=T else E/(d+1)+F(2*d,d+1)*sq_floor(E*T)-F(d,d+1)*T

n=m-q
lines=[(s,n*v) for s,v in eps.items()]
cand={F(0),T}
for i,(si,bi) in enumerate(lines):
    cand.add(bi/si)
    for sj,bj in lines[i+1:]:
        E=(bi-bj)/(si-sj)
        if E>0: cand.add(E)
vals=[]
for E in cand:
    p=max([F(0)]+[bi-si*E for si,bi in lines])
    vals.append((h(E)+eta*p,E))
worst,Emin=min(vals)
ck("stored R equals the exact kink minimum", Rc==worst)
ck("short-tier minimum occurs at E = 0", Emin==0)
ck("m - R > 0", m-Rc>0)
C=(m*Hf-eta*B*(m-q))/(m-Rc)
ck("C reproduces the stored exact rational", C==Cc)
# Conservative upper guard for the official 2026-09-17 record shown as
# 0.672500703679411...; 0.672500704 is strictly ABOVE that displayed value.
ck("C > conservative upper guard 0.672500704 for official record", C>F(672500704,10**9))
# The separate public draft 0.673008527927... is higher than this short tier.
ck("short tier is below the separate 67.3008527927% public research draft", C<F(673008527927,10**12))
ck("certificate node total == 793374", sum(int(x['nodes']) for x in ex['certificates'])==793374)

# If committed replay logs exist, validate their terminal lines and node counts.
logdir=ROOT/'certificates'/'short'
if logdir.exists():
    got=0
    expected={c['slope_decimal']:int(c['nodes']) for c in ex['certificates']}
    for p in sorted(logdir.glob('*.log')):
        txt=p.read_text(errors='replace')
        ms=re.findall(r'slope=([0-9.]+) eps=[0-9.eE+-]+ nodes=(\d+) stack_left=(\d+) HARD=(\d+).*result=(PROVED|INCOMPLETE)',txt)
        if not ms: continue
        slope,n,stack,hard,result=ms[-1]
        ck(f"{p.name}: fail-closed terminal state", result=='PROVED' and stack=='0' and hard=='0')
        if slope in expected:
            ck(f"{p.name}: node count matches lock", int(n)==expected[slope])
            got += int(n)
    ck("committed short logs sum to 793374 nodes", got==793374)

print(f"\n  C = {C.numerator}/{C.denominator}")
print(f"  C = {float(C):.18f}")
print(f"  % = {100*float(C):.15f}")
print("\nRESULT:", "ALL SHORT-TIER EXACT CHECKS PASS" if ok else "FAILURE")
sys.exit(0 if ok else 1)
