# Submission status and external comparison

Author: Libo Wang. Checked 2026-09-17.

## Official challenge status

`https://www.riemannzeta.fun/` currently displays **67.2500703679%** as the kernel-verified
unconditional record, checked by the Lean kernel and an independent replay kernel. The challenge
requires an exact rational `candidateKappa` and proofs of the fixed dyadic and cumulative
critical-line bounds.

The frozen short tier is

`9484806128780811321/14098548107555200000 = 67.275055959117140%`,

so it is strictly above the displayed official threshold. This numerical comparison does **not**
make it an accepted submission.

## Separate public higher research result

The public repository `https://github.com/ainta/zeta-simple-zeros` reports a finite-verifier
argument yielding approximately **67.3008528%** for simple critical-line zeros. That value is
higher than this release's short tier. On 2026-09-17 it is not the value displayed by the
`riemannzeta.fun` kernel-verified leaderboard. This distinction is important: “above the official
challenge record” and “highest public claim” are not the same statement.

The programme's maximum-value research tier, 67.350003708785593%, is numerically above both, but
its complete historical raw 48-shard evidence is not contained in the supplied v10 handoff and no
Lean proof has been accepted.

## Why no submission was attempted in this finalization

A valid challenge upload requires a complete `proof/Solution.lean` satisfying the contract. The
existing `lean/Solution.skeleton.lean` intentionally contains specification holes and is not a
proof. Submitting it would be knowingly invalid and would not advance verification. Therefore no
leaderboard upload was attempted.

## Best next formalization target

The earlier high-value tier required roughly 4.28e8 verifier nodes and was an obvious kernel
replay dead end. The short tier reduces that to 793,374 nodes by spending numerical margin rather
than changing the mathematics. This materially changes the engineering question, but it does not
settle it: benchmark a small reflected interval-certificate consumer in Lean first, then choose a
point on the epsilon/node curve that fits the measured kernel budget.

The governing rule is L11 in `TIERS.md`: first choose the threshold that must be beaten, then
solve backward for the largest safe relaxation of epsilon.
