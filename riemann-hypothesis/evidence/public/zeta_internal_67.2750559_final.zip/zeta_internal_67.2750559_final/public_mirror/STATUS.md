# Status ledger — read before quoting a number

Author: Libo Wang. Frozen 2026-09-17.

| number | status in this release |
|---:|---|
| **67.275055959117140%** | **primary reproducible short tier**. Exact assembly checked over Q; four local inequalities independently replayed from included source: 4/4 PROVED, 793,374 nodes, zero unresolved. Not Lean-submitted. |
| 67.350003708785593% | maximum-value research tier. Exact assembly passes; the supplied v10 handoff does not contain the complete historical raw 48-shard log set, so this finalization does not assert an independent replay of all local certificates. |
| 67.350352375073%, 67.35006335392536% | refuted; see `REFUTATION.md`. |

## Closed for the short tier

1. Frozen witness: `q=8`, `m=617`, `eta=119/125`; constants are in `config/shortlock.json`.
2. Four local inequalities: 4/4 fail-closed `PROVED`; logs are in `certificates/short/`.
3. Exact span capacities, `B=93/23000`, the complete kink minimization, `R=1256139843/312500000`, and final `C` — checked by `verify_short.py` with rational arithmetic.
4. The finite spectral inequality and pinching/pressure-charge accounting — retained in `AUDIT.md`.

## Still open before an official leaderboard entry

1. **Lean formalization.** The challenge accepts a fixed theorem only through Lean plus independent-kernel replay. No complete accepted `Solution.lean` exists here.
2. **Kernel-friendly certificate representation.** 793,374 B&B nodes are 539x smaller than the historical 4.28e8-node tier, but this release has not established that direct Lean replay of those nodes is feasible. A reflected/checkable certificate or further compression may still be required.
3. **Analytic-interface correspondence.** The programme identifies its D0 layer with the public unconditional Zeta23 baseline, but the exact normalization correspondence still needs to be formalized at the hook point described in `SUBMISSION.md`.
4. **Arb re-run in this finalization environment.** `arb_window.py` is preserved, but `python-flint` was unavailable in the sandbox and could not be installed because outbound package access was unavailable. No weaker substitute was used.

## External status

As of 2026-09-17, `riemannzeta.fun` displays 67.2500703679% as the current kernel-verified
record. A separate public research draft reports 67.3008528%; this short tier lies between those
values. The maximum-value research tier lies above both, but is not an accepted Lean entry.

Acceptance by the mathematical community requires independent review; this repository does not
self-declare that status.
