# Provenance

Author: Libo Wang.

| stage | value | evidence state in this release |
|---|---:|---|
| q=6 predecessor | 67.34574870891890% | cited from earlier work; raw artifacts not in this release |
| q=7 candidates | 67.350352375073%, 67.35006335392536% | refuted; witnesses retained |
| q=8 maximum-value tier | 67.350003708785593% | exact assembly retained; supplied v10 archive lacks complete raw historical 48-shard logs |
| **q=8 short tier** | **67.275055959117140%** | **fresh independent 4/4 replay in this finalization + exact rational assembly** |

`MANIFEST.sha256` is generated after finalization and covers every release file except the
manifest itself.
