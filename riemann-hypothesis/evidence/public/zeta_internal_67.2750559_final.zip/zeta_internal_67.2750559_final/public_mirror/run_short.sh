#!/bin/sh
# Replays the four frozen short-certificate inequalities. Fail-closed.
# The first run constructs the fine-table cache; the remaining three then run in parallel.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
CXX=${CXX:-g++}
BUILD=${BUILD_DIR:-"$ROOT/.short_build"}
OUT=${OUT_DIR:-"$ROOT/certificates/short_replay"}
mkdir -p "$BUILD" "$OUT"
"$CXX" -O3 -std=c++17 -march=native "$ROOT/verifier/bb9.cpp" -o "$BUILD/bb9"

run_raw() {
  name=$1; slope=$2; eps=$3
  (cd "$BUILD" && ./bb9 "$slope" "$eps" 2000000 0.000244140625 1 0 0.001) >"$OUT/$name.log" 2>&1
}

# Warm the rigorously constructed point-table cache once, while proving the first certificate.
run_raw s0.5_short 0.5 0.00558
# Coarse range tables depend on epsilon and are rebuilt per process; these three are independent.
run_raw s0.95_short 0.95 0.0067338 & p1=$!
run_raw s1_short     1    0.0068438 & p2=$!
run_raw s1.05_short  1.05 0.0069332 & p3=$!
wait "$p1"; wait "$p2"; wait "$p3"

total=0
audit_one() {
  name=$1; expected=$2
  log="$OUT/$name.log"
  tail_line=$(grep 'slope=.*result=' "$log" | tail -1 || true)
  printf '%s: %s\n' "$name" "$tail_line"
  echo "$tail_line" | grep -q 'stack_left=0 HARD=0.*result=PROVED' || {
    echo "FAIL: $name did not close fail-closed" >&2; exit 1; }
  nodes=$(printf '%s\n' "$tail_line" | sed -n 's/.* nodes=\([0-9][0-9]*\) .*/\1/p')
  [ "$nodes" = "$expected" ] || {
    echo "FAIL: $name nodes=$nodes expected=$expected" >&2; exit 1; }
  total=$((total+nodes))
}

audit_one s0.5_short 12270
audit_one s0.95_short 212210
audit_one s1_short 265637
audit_one s1.05_short 303257
[ "$total" -eq 793374 ] || { echo "FAIL: total nodes=$total" >&2; exit 1; }
echo "ALL 4 SHORT CERTIFICATES PROVED; total_nodes=$total"
